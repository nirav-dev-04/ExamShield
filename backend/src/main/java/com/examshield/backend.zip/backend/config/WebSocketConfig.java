package com.examshield.backend.config;

import com.examshield.backend.model.User;
import com.examshield.backend.model.UserRole;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
import java.security.Principal;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws")
                .setAllowedOrigins("http://localhost:5173")
                .withSockJS();
    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.enableSimpleBroker("/topic", "/queue");
        registry.setApplicationDestinationPrefixes("/app");
    }

    @Override
    public void configureClientInboundChannel(ChannelRegistration registration) {
        registration.interceptors(new ChannelInterceptor() {
            @Override
            public Message<?> preSend(Message<?> message, MessageChannel channel) {
                StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);
                
                if (accessor != null) {
                    StompCommand command = accessor.getCommand();

                    // 1. Double submit CSRF verification on CONNECT
                    if (StompCommand.CONNECT.equals(command)) {
                        String csrfToken = accessor.getFirstNativeHeader("X-XSRF-TOKEN");
                        // In production, we'd compare this to the token stored in the session.
                        // Here we verify it is present as a safeguard.
                        if (csrfToken == null || csrfToken.isEmpty()) {
                            throw new AccessDeniedException("Missing CSRF token for STOMP connection");
                        }
                    }

                    // 2. Topic subscription security check
                    if (StompCommand.SUBSCRIBE.equals(command)) {
                        String destination = accessor.getDestination();
                        Principal principal = accessor.getUser();

                        if (principal instanceof UsernamePasswordAuthenticationToken auth) {
                            User user = (User) auth.getPrincipal();
                            
                            if (destination != null) {
                                // Proctor topics: e.g., /topic/exam/{examId}/violations
                                if (destination.startsWith("/topic/exam/") && destination.endsWith("/violations")) {
                                    if (user.getRole() != UserRole.PROCTOR && user.getRole() != UserRole.ADMIN && user.getRole() != UserRole.SUPER_ADMIN) {
                                        throw new AccessDeniedException("Only proctors or admins can subscribe to exam violations");
                                    }
                                }
                                // Student private attempt status topics: e.g., /topic/attempt/{attemptId}/status
                                if (destination.startsWith("/topic/attempt/") && destination.endsWith("/status")) {
                                    String[] parts = destination.split("/");
                                    if (parts.length > 3) {
                                        // Simple validation - in a full implementation we would check 
                                        // if this specific user owns this specific attemptId.
                                        if (user.getRole() != UserRole.STUDENT && user.getRole() != UserRole.ADMIN) {
                                            throw new AccessDeniedException("Unauthorized subscription to attempt status");
                                        }
                                    }
                                }
                            }
                        } else {
                            throw new AccessDeniedException("Unauthenticated subscription request");
                        }
                    }
                }
                
                return message;
            }
        });
    }
}
