package com.examshield.backend.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ExamCreateRequest {
    @NotBlank(message = "Exam title is required")
    @Size(max = 200, message = "Title must not exceed 200 characters")
    private String title;

    private String description;

    @NotNull(message = "Start time is required")
    @Future(message = "Start time must be in the future")
    private LocalDateTime startTime;

    @NotNull(message = "End time is required")
    private LocalDateTime endTime;

    @Min(value = 0, message = "Late entry minutes must be positive")
    private Integer lateEntryMinutes;

    @NotNull(message = "Duration in minutes is required")
    @Min(value = 1, message = "Duration must be at least 1 minute")
    private Integer durationMinutes;

    @NotNull(message = "Total questions is required")
    @Min(value = 1, message = "Total questions must be at least 1")
    private Integer totalQuestions;

    @Min(value = 0, message = "Easy count must be positive")
    private Integer easyCount;

    @Min(value = 0, message = "Medium count must be positive")
    private Integer mediumCount;

    @Min(value = 0, message = "Hard count must be positive")
    private Integer hardCount;

    @NotNull(message = "Passing marks is required")
    @Min(value = 1, message = "Passing marks must be at least 1")
    private Integer passingMarks;

    @Min(value = 1, message = "Max violations must be at least 1")
    private Integer maxViolations;

    private Boolean isSectioned;

    @Valid
    private List<ExamSectionDto> sections;
}
