package com.examshield.backend.dto;

import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
public class ExamAttemptResponseDTO {
    private Long id;
    private Long examId;
    private String examTitle;
    private String studentName;
    private String status;
    private LocalDateTime startedAt;
    private Integer durationMinutes;
    private Long remainingSeconds; // Server-authoritative timer value from Redis
    private List<QuestionResponseDTO> questions; // Shuffled, answer-stripped questions
    private Integer violationsCount;
}
