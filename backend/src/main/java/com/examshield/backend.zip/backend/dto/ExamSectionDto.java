package com.examshield.backend.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ExamSectionDto {
    @NotBlank(message = "Section name is required")
    private String name;

    @NotNull(message = "Question count is required")
    @Min(value = 1, message = "Section must have at least 1 question")
    private Integer questionCount;

    private Integer durationMinutes; // optional per section timer
}
