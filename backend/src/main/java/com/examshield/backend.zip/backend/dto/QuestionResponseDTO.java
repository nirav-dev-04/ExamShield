package com.examshield.backend.dto;

import com.examshield.backend.model.Difficulty;
import com.examshield.backend.model.QuestionType;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class QuestionResponseDTO {
    private Long id;
    private Long topicId;
    private String topicName;
    private QuestionType type;
    private String questionText;
    private String optionA;
    private String optionB;
    private String optionC;
    private String optionD;
    private Difficulty difficulty;
    private Integer marks;
    private Integer sequenceOrder; // Order in student attempt, if applicable
}
