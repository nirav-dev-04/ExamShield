package com.examshield.backend.dto;

import com.examshield.backend.model.ViolationType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ViolationReportRequest {
    @NotNull(message = "Violation type is required")
    private ViolationType type;
}
