package com.examshield.backend.dto;

import com.examshield.backend.model.UserRole;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserResponseDTO {
    private Long id;
    private String fullName;
    private String email;
    private UserRole role;
    private String enrollmentNo;
    private Boolean isActive;
}
