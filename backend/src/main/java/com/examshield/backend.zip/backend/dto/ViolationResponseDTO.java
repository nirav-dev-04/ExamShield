package com.examshield.backend.dto;

import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Builder
public class ViolationResponseDTO {
    private Long id;
    private String studentName;
    private String enrollmentNo;
    private String type;
    private LocalDateTime occurredAt;
    private Long attemptId;
    private Long examId;
}
